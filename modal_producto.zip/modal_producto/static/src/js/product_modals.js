odoo.define('modal_producto.snippet', function (require) {
'use strict';

	var ajax = require('web.ajax');

	var publicWidget = require('web.public.widget');

	publicWidget.registry.modal_producto = publicWidget.Widget.extend({
		selector: '.details_modal_product',
		start: function () {

			$(document).ready(function() {

				$("#ver_ficha_tecnica").click(function(){

					var ficha = $(".imgFicha").attr("src");

					$(".imgFichas").attr('src', ficha);

					$('#exampleModal').modal('toggle');

				});

			});

		}
	});

});



