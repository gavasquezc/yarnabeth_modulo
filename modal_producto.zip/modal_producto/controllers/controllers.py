# -*- coding: utf-8 -*-
from odoo import http

# class ModalProducto(http.Controller):
#     @http.route('/modal_producto/modal_producto/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/modal_producto/modal_producto/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('modal_producto.listing', {
#             'root': '/modal_producto/modal_producto',
#             'objects': http.request.env['modal_producto.modal_producto'].search([]),
#         })

#     @http.route('/modal_producto/modal_producto/objects/<model("modal_producto.modal_producto"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('modal_producto.object', {
#             'object': obj
#         })